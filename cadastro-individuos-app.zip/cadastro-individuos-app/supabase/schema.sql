-- ESQUEMA INICIAL DE REFERÊNCIA — NÃO APLICAR EM PRODUÇÃO SEM REVISÃO.
-- Antes de cadastrar qualquer dado real: autorização institucional, análise jurídica,
-- classificação da informação, política de retenção e revisão de segurança.
-- Ative RLS e ajuste as políticas ao modelo de identidade institucional aprovado.
create extension if not exists pgcrypto;

create table if not exists public.individuos (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  cpf text,
  rg text,
  matricula text,
  apelido text,
  aniversario date,
  endereco1 text,
  endereco2 text,
  anotacoes text,
  crimes text,
  caracteristicas text,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table if not exists public.fotos (
  id uuid primary key default gen_random_uuid(),
  individuo_id uuid not null references public.individuos(id) on delete cascade,
  caminho_armazenamento text not null,
  tipo text,
  criado_em timestamptz not null default now()
);

create table if not exists public.veiculos (
  id uuid primary key default gen_random_uuid(),
  placa text not null,
  marca text,
  modelo text,
  cor text,
  anotacoes text,
  criado_em timestamptz not null default now()
);

create table if not exists public.individuo_veiculo (
  individuo_id uuid not null references public.individuos(id) on delete cascade,
  veiculo_id uuid not null references public.veiculos(id) on delete cascade,
  tipo_vinculo text,
  observacoes text,
  criado_em timestamptz not null default now(),
  primary key (individuo_id, veiculo_id)
);

create table if not exists public.ocorrencias (
  id uuid primary key default gen_random_uuid(),
  individuo_id uuid not null references public.individuos(id) on delete cascade,
  numero_referencia text,
  natureza text,
  data_fato date,
  observacoes text,
  criado_em timestamptz not null default now()
);

create table if not exists public.auditoria (
  id bigint generated always as identity primary key,
  usuario_id uuid,
  operacao text not null,
  tabela_alvo text not null,
  registro_id text,
  criado_em timestamptz not null default now(),
  detalhes jsonb
);

alter table public.individuos enable row level security;
alter table public.fotos enable row level security;
alter table public.veiculos enable row level security;
alter table public.individuo_veiculo enable row level security;
alter table public.ocorrencias enable row level security;
alter table public.auditoria enable row level security;

-- Intencionalmente não são criadas políticas permissivas aqui.
-- Sem políticas explícitas, clientes comuns não poderão consultar/modificar tabelas.
-- Implementar políticas restritivas após definir identidade, papéis e autorização.
-- Nunca colocar service_role key no frontend nem no GitHub.
