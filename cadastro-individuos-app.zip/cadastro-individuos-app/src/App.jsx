import { useMemo, useState } from 'react'
import { Search, Plus, Menu, UserRound, CarFront, Globe, Pencil, MoreHorizontal, X, ArrowLeft, Copy, MapPin, ShieldAlert, Camera, Save } from 'lucide-react'

const initialPeople = [
  { id: 1, nome: 'Exemplo de cadastro', cpf: '', rg: '', matricula: '', apelido: '', aniversario: '', endereco1: '', endereco2: '', anotacoes: 'Registro fictício para demonstração.', crimes: '', caracteristicas: '', foto: '' },
  { id: 2, nome: 'Pessoa demonstrativa', cpf: '', rg: '', matricula: '', apelido: '', aniversario: '', endereco1: '', endereco2: '', anotacoes: 'Use somente dados fictícios durante os testes.', crimes: '', caracteristicas: '', foto: '' }
]
const initialVehicles = [
  { id: 1, placa: 'ABC1D23', marca: 'Marca demonstrativa', modelo: 'Modelo de exemplo', cor: 'Prata', condutor: 'Exemplo de cadastro', anotacoes: 'Placa fictícia; não corresponde a veículo real.' }
]
const blankPerson = { nome:'', cpf:'', rg:'', matricula:'', apelido:'', aniversario:'', endereco1:'', endereco2:'', anotacoes:'', crimes:'', caracteristicas:'', foto:'' }
const blankVehicle = { placa:'', marca:'', modelo:'', cor:'', condutor:'', anotacoes:'' }

export default function App() {
  const [tab, setTab] = useState('Cadastro')
  const [people, setPeople] = useState(initialPeople)
  const [vehicles, setVehicles] = useState(initialVehicles)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState(null)
  const [modal, setModal] = useState('')
  const [personForm, setPersonForm] = useState(blankPerson)
  const [vehicleForm, setVehicleForm] = useState(blankVehicle)
  const [toast, setToast] = useState('')

  const filteredPeople = useMemo(() => people.filter(p => `${p.nome} ${p.cpf} ${p.rg} ${p.apelido}`.toLowerCase().includes(query.toLowerCase())), [people, query])
  const filteredVehicles = useMemo(() => vehicles.filter(v => `${v.placa} ${v.marca} ${v.modelo} ${v.condutor}`.toLowerCase().includes(query.toLowerCase())), [vehicles, query])
  const notify = (message) => { setToast(message); window.setTimeout(() => setToast(''), 2800) }
  const openPerson = (person) => { setSelected(person); setModal('detail') }
  const startPerson = () => { setPersonForm(blankPerson); setModal('person') }
  const savePerson = (e) => {
    e.preventDefault()
    if (!personForm.nome.trim()) return
    const item = { ...personForm, id: Date.now() }
    setPeople(prev => [item, ...prev]); setModal(''); setQuery('')
    notify('Cadastro de demonstração adicionado nesta sessão.')
  }
  const saveVehicle = (e) => {
    e.preventDefault()
    if (!vehicleForm.placa.trim()) return
    setVehicles(prev => [{ ...vehicleForm, id: Date.now(), placa: vehicleForm.placa.toUpperCase().replace(/[^A-Z0-9]/g, '') }, ...prev])
    setModal(''); setQuery(''); notify('Veículo de demonstração adicionado nesta sessão.')
  }
  const copyText = async (text) => {
    try { await navigator.clipboard.writeText(text); notify('Informação copiada.') }
    catch { notify('Não foi possível copiar neste navegador.') }
  }
  const handlePhoto = (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 3 * 1024 * 1024) { notify('Escolha uma imagem de até 3 MB para o protótipo.'); return }
    const reader = new FileReader()
    reader.onload = () => setPersonForm(f => ({ ...f, foto: reader.result }))
    reader.readAsDataURL(file)
  }

  return <div className="app-shell">
    <header className="topbar">
      <button className="icon-button light" aria-label="Menu" onClick={() => notify('Menu de navegação: protótipo inicial')}><Menu size={25}/></button>
      <strong>{selected && modal === 'detail' ? selected.nome : tab}</strong>
      {selected && modal === 'detail' && <button className="icon-button light" onClick={() => setModal('')} aria-label="Voltar"><ArrowLeft/></button>}
    </header>

    <main className="main-content">
      <div className="stats">
        <div>TOTAL DE PESSOAS: <b>{people.length.toLocaleString('pt-BR')}</b></div>
        <div>CADASTRO COM FOTOS: <b>{people.filter(p => p.foto).length.toLocaleString('pt-BR')}</b></div>
        <div>TOTAL DE CPF: <b>{people.filter(p => p.cpf).length.toLocaleString('pt-BR')}</b></div>
      </div>

      {modal === 'detail' && selected ? <section className="detail">
        <div className="portrait large">{selected.foto ? <img src={selected.foto} alt="Foto de demonstração"/> : <UserRound size={72}/>}</div>
        <div className="detail-actions">
          <button className="primary" onClick={() => { setPersonForm(selected); setModal('edit-person') }}><Pencil size={18}/> Editar</button>
          <button className="secondary" onClick={() => copyText([selected.nome, selected.cpf && `CPF: ${selected.cpf}`, selected.rg && `RG: ${selected.rg}`, selected.endereco1, selected.endereco2].filter(Boolean).join('\n'))}><Copy size={18}/> Copiar dados</button>
        </div>
        <h1>{selected.nome}</h1>
        <DetailLine label="CPF" value={selected.cpf}/>
        <DetailLine label="RG" value={selected.rg}/>
        <DetailLine label="Matrícula" value={selected.matricula}/>
        <DetailLine label="Apelido/Vulgo" value={selected.apelido}/>
        <DetailLine label="Aniversário" value={selected.aniversario}/>
        <DetailLine label="Endereços" value={[selected.endereco1, selected.endereco2].filter(Boolean).join('\n')}/>
        <DetailLine label="Crime / natureza informada" value={selected.crimes}/>
        <DetailLine label="Características" value={selected.caracteristicas}/>
        <DetailLine label="Anotações" value={selected.anotacoes}/>
        <button className="primary full" onClick={() => setModal('')}><ArrowLeft size={18}/> Voltar</button>
      </section> : <>
        <div className="section-heading">
          <h1>{tab}</h1>
          <button className="primary add-button" onClick={() => tab === 'Veículos' ? (setVehicleForm(blankVehicle), setModal('vehicle')) : startPerson()}><Plus size={22}/> Add</button>
        </div>
        <label className="searchbar"><Search size={24}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Procurar"/></label>
        {tab === 'Cadastro' ? <div className="people-grid">
          {filteredPeople.map(person => <button className="person-card" key={person.id} onClick={() => openPerson(person)}>
            <div className="card-photo">{person.foto ? <img src={person.foto} alt="Foto de demonstração"/> : <div className="placeholder"><UserRound size={58}/><span>SEM FOTO</span></div>}<span className="more"><MoreHorizontal/></span></div>
            <div className="card-info"><strong>{person.nome}</strong><span>CPF: {person.cpf || '—'}</span><span>RG: {person.rg || '—'}</span></div>
          </button>)}
          {filteredPeople.length === 0 && <p className="empty">Nenhum cadastro encontrado.</p>}
        </div> : tab === 'Veículos' ? <div className="vehicle-list">
          <div className="count">TOTAL: {vehicles.length.toLocaleString('pt-BR')}</div>
          {filteredVehicles.map(v => <div className="vehicle-row" key={v.id}><div className="vehicle-icon"><CarFront/></div><button className="vehicle-text" onClick={() => { setSelected(v); setModal('vehicle-detail') }}><b>{v.placa}</b><span>{v.marca} {v.modelo}</span></button><button className="icon-button" aria-label="Opções" onClick={() => { setSelected(v); setModal('vehicle-detail') }}><MoreHorizontal/></button></div>)}
          {filteredVehicles.length === 0 && <p className="empty">Nenhum veículo encontrado.</p>}
        </div> : <section className="simple-panel"><div className="simple-icon">{tab === 'Sites' ? <Globe size={34}/> : <Pencil size={34}/>}</div><h2>{tab}</h2><p>Área reservada para a próxima etapa de desenvolvimento.</p><p className="muted">Os módulos serão ativados após a definição dos requisitos e das permissões de acesso.</p></section>}
      </>}
    </main>

    <nav className="bottom-nav">
      {[['Cadastro',UserRound],['Veículos',CarFront],['Sites',Globe],['Fiscalização',Pencil]].map(([name,Icon]) => <button key={name} className={tab === name ? 'nav-item active' : 'nav-item'} onClick={() => { setTab(name); setModal(''); setSelected(null); setQuery('') }}><Icon size={25}/><span>{name}</span></button>)}
    </nav>

    {(modal === 'person' || modal === 'edit-person') && <div className="overlay" onClick={() => setModal('')}><section className="modal" onClick={e => e.stopPropagation()}>
      <div className="modal-head"><h2>{modal === 'edit-person' ? 'Editar Pessoa' : 'Adicionar Pessoa'}</h2><button className="icon-button" onClick={() => setModal('')}><X/></button></div>
      <form onSubmit={e => { if (modal === 'edit-person') { e.preventDefault(); setPeople(prev => prev.map(p => p.id === personForm.id ? personForm : p)); setSelected(personForm); setModal('detail'); notify('Alteração local de demonstração salva.') } else savePerson(e) }}>
        <div className="form-grid">
          <Field label="CPF (opcional)" value={personForm.cpf} onChange={v => setPersonForm(f => ({...f, cpf:v.replace(/\D/g,'').slice(0,11)}))} placeholder="Digite apenas números (11 dígitos)" maxLength={11}/>
          <Field label="Nome" value={personForm.nome} onChange={v => setPersonForm(f => ({...f,nome:v}))} required/>
          <Field label="RG" value={personForm.rg} onChange={v => setPersonForm(f => ({...f,rg:v}))}/>
          <Field label="Matrícula" value={personForm.matricula} onChange={v => setPersonForm(f => ({...f,matricula:v}))}/>
          <Field label="Apelido/Vulgo" value={personForm.apelido} onChange={v => setPersonForm(f => ({...f,apelido:v}))}/>
          <Field label="Aniversário" type="date" value={personForm.aniversario} onChange={v => setPersonForm(f => ({...f,aniversario:v}))}/>
          <Field label="Endereço 1" value={personForm.endereco1} onChange={v => setPersonForm(f => ({...f,endereco1:v}))}/>
          <Field label="Endereço 2" value={personForm.endereco2} onChange={v => setPersonForm(f => ({...f,endereco2:v}))}/>
          <Field label="Anotações" value={personForm.anotacoes} onChange={v => setPersonForm(f => ({...f,anotacoes:v}))} area/>
          <Field label="Crimes / natureza informada" value={personForm.crimes} onChange={v => setPersonForm(f => ({...f,crimes:v}))}/>
          <Field label="Características" value={personForm.caracteristicas} onChange={v => setPersonForm(f => ({...f,caracteristicas:v}))}/>
          <label className="field photo-field"><span><Camera size={16}/> Foto de rosto (protótipo local)</span><input type="file" accept="image/*" onChange={handlePhoto}/>{personForm.foto && <img className="preview" src={personForm.foto} alt="Pré-visualização da foto"/>}</label>
        </div>
        <p className="form-note"><ShieldAlert size={15}/> Protótipo: os dados ficam somente na memória desta sessão e não são enviados a um banco de dados.</p>
        <div className="modal-actions"><button type="button" className="secondary" onClick={() => setModal('')}>Cancelar</button><button type="submit" className="primary"><Save size={18}/> Salvar</button></div>
      </form>
    </section></div>}

    {modal === 'vehicle' && <div className="overlay" onClick={() => setModal('')}><section className="modal" onClick={e => e.stopPropagation()}>
      <div className="modal-head"><h2>Adicionar Veículo</h2><button className="icon-button" onClick={() => setModal('')}><X/></button></div>
      <form onSubmit={saveVehicle}><div className="form-grid">
        <Field label="Placa" value={vehicleForm.placa} onChange={v => setVehicleForm(f => ({...f,placa:v.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,7)}))} placeholder="Digite a placa sem traço" required maxLength={7}/>
        <Field label="Marca" value={vehicleForm.marca} onChange={v => setVehicleForm(f => ({...f,marca:v}))}/>
        <Field label="Modelo" value={vehicleForm.modelo} onChange={v => setVehicleForm(f => ({...f,modelo:v}))}/>
        <Field label="Cor" value={vehicleForm.cor} onChange={v => setVehicleForm(f => ({...f,cor:v}))}/>
        <label className="field"><span>Condutor vinculado (demonstração)</span><select value={vehicleForm.condutor} onChange={e => setVehicleForm(f => ({...f,condutor:e.target.value}))}><option value="">—</option>{people.map(p => <option key={p.id} value={p.nome}>{p.nome}</option>)}</select></label>
        <Field label="Anotações" value={vehicleForm.anotacoes} onChange={v => setVehicleForm(f => ({...f,anotacoes:v}))} area/>
      </div><p className="form-note"><ShieldAlert size={15}/> Dados de demonstração: não são persistidos em banco externo.</p><div className="modal-actions"><button type="button" className="secondary" onClick={() => setModal('')}>Cancelar</button><button className="primary" type="submit"><Save size={18}/> Salvar</button></div></form>
    </section></div>}

    {modal === 'vehicle-detail' && selected && <div className="overlay" onClick={() => setModal('')}><section className="modal" onClick={e => e.stopPropagation()}><div className="modal-head"><h2>Detalhes do Veículo</h2><button className="icon-button" onClick={() => setModal('')}><X/></button></div><h1>{selected.placa}</h1><p>{selected.marca} {selected.modelo}</p><DetailLine label="Cor" value={selected.cor}/><DetailLine label="Condutor" value={selected.condutor}/><DetailLine label="Anotações" value={selected.anotacoes}/><button className="primary full" onClick={() => setModal('')}><ArrowLeft size={18}/> Voltar</button></section></div>}
    {toast && <div className="toast">{toast}</div>}
    <footer className="safety-footer">PROTÓTIPO • NÃO UTILIZAR COM DADOS REAIS OU SIGILOSOS</footer>
  </div>
}

function Field({ label, value, onChange, placeholder='', required=false, type='text', maxLength, area=false }) {
  return <label className={`field ${area ? 'span-two' : ''}`}><span>{label}{required && <em> Necessário</em>}</span>{area ? <textarea value={value || ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={3}/> : <input type={type} value={value || ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} required={required} maxLength={maxLength}/>}</label>
}
function DetailLine({label,value}) {
  if (!value) return null
  return <div className="detail-line"><span>{label}</span><b>{value}</b></div>
}