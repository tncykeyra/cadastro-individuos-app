# Cadastro de Indivíduos — protótipo inicial

Interface web responsiva inspirada nas telas de referência, preparada para evoluir para aplicativo Android.

## Importante: protótipo, não sistema operacional

- Use apenas dados fictícios nesta versão.
- Os cadastros e veículos adicionados pela interface ficam apenas na memória da sessão e desaparecem ao recarregar.
- A conexão com banco externo ainda não está ativada.
- Não insira dados pessoais reais, fotografias reais, dados policiais, antecedentes ou informações sigilosas.
- Antes de uso institucional, obtenha autorização, valide a base legal e os requisitos aplicáveis e submeta o projeto a revisão de segurança e de proteção de dados.

## Executar

Requer Node.js 20 ou mais recente.

```bash
npm install
npm run dev
```

Para gerar a versão web:

```bash
npm run build
```

Os arquivos compilados serão criados na pasta `dist`.

## Estrutura

- `src/` — interface React e estilos responsivos.
- `supabase/schema.sql` — proposta inicial de estrutura de banco; não aplicar em produção sem revisão.
- `.env.example` — exemplo sem credenciais.
- `.github/workflows/deploy.yml` — publicação de demonstração no GitHub Pages.

## Publicar no GitHub Pages

1. Envie o conteúdo deste projeto para um repositório GitHub.
2. Abra **Settings → Pages**.
3. Em **Build and deployment**, selecione **GitHub Actions**.
4. Abra a aba **Actions** e acompanhe o workflow `Deploy web prototype`.
5. Quando concluir, consulte a URL publicada na seção **Settings → Pages**.

## Próximas etapas antes de banco real

1. Definir os papéis e a identidade institucional.
2. Revisar políticas de acesso por linha (RLS) e auditoria no Supabase.
3. Criar bucket privado para fotografias e regras de acesso restritas.
4. Integrar autenticação e persistência no servidor.
5. Fazer testes de segurança, cópia de segurança e restauração.
6. Só então avaliar empacotamento Android/APK.

Nunca exponha credenciais privadas em arquivos frontend. Nunca coloque a chave `service_role` no código do navegador ou no repositório.
